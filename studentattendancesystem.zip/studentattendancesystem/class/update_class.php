<?php
      // Connect to the database
      include("../conig.php");

      // Get class details from POST request
      $classId = $_POST["class_id"];
      $className = $_POST["class_name"];
      $section = $_POST["section"];
      $classTeacher = $_POST["class_teacher"];
      $classSchedule = $_POST["class_schedule"];
      $otherDetails = $_POST["other_details"];

      // Prepare UPDATE query
      $sql = "UPDATE Class SET class_name = '$className', section = '$section', class_teacher = '$classTeacher', class_schedule = '$classSchedule', other_details = '$otherDetails' WHERE class_id = $classId";

      // Execute UPDATE query
      if (mysqli_query($conn, $sql)) {
        header("Location: view_classes.php");
      } else {
        echo "<div class='alert alert-danger'>Error updating class: " . mysqli_error($conn) . "</div>";
      }

      mysqli_close($conn);
    ?>