-- Create database for student attendance system
CREATE DATABASE StudentAttendanceSystem;

USE StudentAttendanceSystem;

-- Create Students table
CREATE TABLE Students (
  student_id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  roll_number VARCHAR(255) UNIQUE NOT NULL,
  class_id INT NOT NULL,
  section VARCHAR(255) NOT NULL,
  admission_number VARCHAR(255) UNIQUE NOT NULL,
  FOREIGN KEY (class_id) REFERENCES Class(class_id)
);

-- Create Class table
CREATE TABLE Class (
  class_id INT PRIMARY KEY AUTO_INCREMENT,
  class_name VARCHAR(255) NOT NULL,
  section VARCHAR(255) NOT NULL,
  class_teacher VARCHAR(255) NOT NULL,
  class_schedule VARCHAR(255) NOT NULL,
  other_details VARCHAR(255)
);

-- Create Attendance Records table
CREATE TABLE AttendanceRecords (
  attendance_id INT PRIMARY KEY AUTO_INCREMENT,
  student_id INT NOT NULL,
  class_id INT NOT NULL,
  attendance_date DATE NOT NULL,
  status VARCHAR(255) NOT NULL,
  remarks VARCHAR(255),
  FOREIGN KEY (student_id) REFERENCES Students(student_id),
  FOREIGN KEY (class_id) REFERENCES Class(class_id)
);

-- Create Subjects table
CREATE TABLE Subjects (
  subject_id INT PRIMARY KEY AUTO_INCREMENT,
  subject_name VARCHAR(255) NOT NULL
);

-- Create Attendance_Subjects table
CREATE TABLE Attendance_Subjects (
  attendance_id INT NOT NULL,
  subject_id INT NOT NULL,
  PRIMARY KEY (attendance_id, subject_id),
  FOREIGN KEY (attendance_id) REFERENCES AttendanceRecords(attendance_id),
  FOREIGN KEY (subject_id) REFERENCES Subjects(subject_id)
);

-- Create Teachers table
CREATE TABLE Teachers (
  teacher_id INT PRIMARY KEY AUTO_INCREMENT,
  teacher_name VARCHAR(255) NOT NULL,
  designation VARCHAR(255) NOT NULL,
  department VARCHAR(255) NOT NULL,
  other_details VARCHAR(255)
);

-- Create Teacher_Subjects table
CREATE TABLE Teacher_Subjects (
  teacher_id INT NOT NULL,
  subject_id INT NOT NULL,
  PRIMARY KEY (teacher_id, subject_id),
  FOREIGN KEY (teacher_id) REFERENCES Teachers(teacher_id),
  FOREIGN KEY (subject_id) REFERENCES Subjects(subject_id)
);
