<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add Class | Student Attendance System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <style>
    body {
      padding: 20px;
    }
  </style>
</head>
<body>
<?php
include('../menu.php');
?>

  <div class="container">
    <h1 class="mt-4 mb-4">Add Class</h1>

    <?php
    include("../conig.php");
      // Process form data if submitted
      if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $className = $_POST["class_name"];
        $section = $_POST["section"];
        $classTeacher = $_POST["class_teacher"];
        $classSchedule = $_POST["class_schedule"];
        $otherDetails = $_POST["other_details"];

        // Sanitize and validate data
        $className = mysqli_real_escape_string($conn, $className);
        $section = mysqli_real_escape_string($conn, $section);
        $classTeacher = mysqli_real_escape_string($conn, $classTeacher);
        $classSchedule = mysqli_real_escape_string($conn, $classSchedule);
        $otherDetails = mysqli_real_escape_string($conn, $otherDetails);

        $sql = "INSERT INTO Class (class_name, section, class_teacher, class_schedule, other_details) VALUES ('$className', '$section', '$classTeacher', '$classSchedule', '$otherDetails')";

        // Execute INSERT query
        if (mysqli_query($conn, $sql)) {
          echo "<div class='alert alert-success'>Class added successfully.</div>";
        } else {
          echo "<div class='alert alert-danger'>Error adding class: " . mysqli_error($conn) . "</div>";
        }
      }
    ?>

    <form action="add_class.php" method="post">
      <div class="mb-3">
        <label for="class_name" class="form-label">Class Name:</label>
        <input type="text" class="form-control" id="class_name" name="class_name" required>
      </div>

      <div class="mb-3">
        <label for="section" class="form-label">Section:</label>
        <input type="text" class="form-control" id="section" name="section" required>
      </div>

      <div class="mb-3">
        <label for="class_teacher" class="form-label">Class Teacher:</label>
        <input type="text" class="form-control" id="class_teacher" name="class_teacher" required>
      </div>

      <div class="mb-3">
        <label for="class_schedule" class="form-label">Class Schedule:</label>
        <input type="text" class="form-control" id="class_schedule" name="class_schedule" required>
      </div>

      <div class="mb-3">
        <label for="other_details" class="form-label">Other Details:</label>
        <textarea class="form-control" id="other_details" name="other_details" rows="3"></textarea>
      </div>

      <button type="submit" class="btn btn-primary">Add Class</button>
    </form>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>
