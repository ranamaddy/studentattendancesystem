
    <?php
      include("../conig.php");

      // Get class ID from POST request
      $classId = $_POST["class_id"];

      // Prepare DELETE query
      $sql = "DELETE FROM Class WHERE class_id = $classId";

      // Execute DELETE query
      if (mysqli_query($conn, $sql)) {
        header("Location: view_classes.php");
      } else {
        echo "<div class='alert alert-danger'>Error deleting class: " . mysqli_error($conn) . "</div>";
      }

      mysqli_close($conn);
    ?>

 