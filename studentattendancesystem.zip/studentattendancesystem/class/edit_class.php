<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Class | Student Attendance System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <style>
    body {
      padding: 20px;
    }
  </style>
</head>
<body>
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">Student Attendance System</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" href="dashboard.php">Dashboard</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="students.php">Student Management</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="classes.php">Class Management</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="teachers.php">Teacher Management</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="attendance.php">Attendance Management</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="reports.php">Reports</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="settings.php">Settings</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <div class="container">
    <?php
      // Connect to the database
      $dbHost = "localhost";
      $dbUsername = "root";
      $dbPassword = "";
      $dbName = "StudentAttendanceSystem";

      $conn = mysqli_connect($dbHost, $dbUsername, $dbPassword, $dbName);

      if (!$conn) {
        die("Failed to connect to database: " . mysqli_connect_error());
      }

      // Get class ID from URL parameter
      $classId = $_GET["id"];

      // Fetch class details
      $sql = "SELECT class_name, section, class_teacher, class_schedule, other_details FROM Class WHERE class_id = $classId";
      $result = mysqli_query($conn, $sql);

      if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $className = $row["class_name"];
        $section = $row["section"];
        $classTeacher = $row["class_teacher"];
        $classSchedule = $row["class_schedule"];
        $otherDetails = $row["other_details"];
      } else {
        echo "<div class='alert alert-danger'>Class not found.</div>";
      }
    ?>

    <h1 class="mt-4 mb-4">Edit Class</h1>

    <form action="update_class.php" method="post">
      <input type="hidden" name="class_id" value="<?php echo $classId; ?>">

<div class="mb-3">
  <label for="class_name" class="form-label">Class Name:</label>
  <input type="text" class="form-control" id="class_name" name="class_name" value="<?php echo $className; ?>" required>
</div>

<div class="mb-3">
  <label for="section" class="form-label">Section:</label>
  <input type="text" class="form-control" id="section" name="section" value="<?php echo $section; ?>" required>
</div>

<div class="mb-3">
  <label for="class_teacher" class="form-label">Class Teacher:</label>
  <input type="text" class="form-control" id="class_teacher" name="class_teacher" value="<?php echo $classTeacher; ?>" required>
</div>

<div class="mb-3">
  <label for="class_schedule" class="form-label">Class Schedule:</label>
  <input type="text" class="form-control" id="class_schedule" name="class_schedule" value="<?php echo $classSchedule; ?>" required>
</div>

<div class="mb-3">
  <label for="other_details" class="form-label">Other Details:</label>
  <textarea class="form-control" id="other_details" name="other_details" rows="3"><?php echo $otherDetails; ?></textarea>
</div>

<button type="submit" class="btn btn-primary">Update Class</button>
</form>

<a href="view_classes.php" class="btn btn-secondary mt-4">Back to Classes</a>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>

