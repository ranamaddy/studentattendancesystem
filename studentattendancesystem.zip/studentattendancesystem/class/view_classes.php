<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>View Classes | Student Attendance System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <style>
    body {
      padding: 20px;
    }
  </style>
</head>
<body>
<?php
include('../menu.php');
?>

  <div class="container">
    <h1 class="mt-4 mb-4">View Classes</h1>

    <?php
    include("../conig.php");

      // Fetch classes from database
      $sql = "SELECT class_id, class_name, section, class_teacher, class_schedule, other_details FROM Class";
      $result = mysqli_query($conn, $sql);

      if (mysqli_num_rows($result) > 0) {
        echo "<table class='table table-striped'>";
        echo "<thead>";
        echo "<tr>";
        echo "<th>Class Name</th>";
        echo "<th>Section</th>";
        echo "<th>Class Teacher</th>";
        echo "<th>Class Schedule</th>";
        echo "<th>Other Details</th>";
        echo "<th>Actions</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";

        while ($row = mysqli_fetch_assoc($result)) {
          $classId = $row["class_id"];
          $className = $row["class_name"];
          $section = $row["section"];
          $classTeacher = $row["class_teacher"];
          $classSchedule = $row["class_schedule"];
          $otherDetails = $row["other_details"];

          echo "<tr>";
          echo "<td>$className</td>";
          echo "<td>$section</td>";
          echo "<td>$classTeacher</td>";
          echo "<td>$classSchedule</td>";
          echo "<td>$otherDetails</td>";
          echo "<td>";
          echo "<a href='edit_class.php?id=$classId' class='btn btn-primary'>Edit</a>";
          echo "<form action='delete_class.php' method='post'>";
          echo "<input type='hidden' name='class_id' value='$classId'>";
          echo "<button type='submit' class='btn btn-danger' onclick='return confirm(`Are you sure you want to delete this class?`)'>Delete</button>";
          echo "</form>";
          echo "</td>";
          echo "</tr>";
        }

        echo "</tbody>";
        echo "</table>";
      } else {
        echo "<div class='alert alert-info'>No classes found.</div>";
      }

      mysqli_close($conn);
    ?>

    <a href="add_class.php" class="btn btn-primary mt-4">Add Class</a>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>
