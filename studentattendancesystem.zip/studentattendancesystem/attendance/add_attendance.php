<?php
// Connect to the database
$host = "localhost";
$user = "root";
$password = "";
$db = "StudentAttendanceSystem";

$conn = mysqli_connect($host, $user, $password, $db);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$result="";
// Get list of classes
$classQuery = "SELECT class_id, class_name FROM class";
$classResult = mysqli_query($conn, $classQuery);

if (isset($_POST['class_id'])) {
    $selectedClassId = $_POST['class_id'];
    $sql = "SELECT s.student_id, s.name, s.roll_number
            FROM students s
            JOIN class c ON s.class_id = c.class_id
            WHERE c.class_id = $selectedClassId";
            $result = mysqli_query($conn, $sql);
} else {
    $selectedClassId = "";
    $sql = "";
}


?>

<html>
<head>
    <title>Attendance Form</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>

<div class="container">

    <h2>Mark Attendance</h2>

    <form method="POST" action="">

        <div class="form-group">
            <label>Date</label>
            <input type="date" name="date" class="form-control">
        </div>

        <div class="form-group">
            <label>Select Class:</label>
            <select name="class_id" class="form-control" onchange="this.form.submit()">
                <option value="">Select Class</option>
                <?php while ($classRow = mysqli_fetch_assoc($classResult)) { ?>
                <option value="<?php echo $classRow['class_id']; ?>" <?php if ($classRow['class_id'] == $selectedClassId) echo 'selected'; ?>>
                    <?php echo $classRow['class_name']; ?>
                </option>
                <?php } ?>
            </select>
        </div>

        <?php if ($selectedClassId) { ?>
        <table class="table table-bordered">
            <tr>
                <th>Student ID</th>
                <th>Name</th>
                <th>Roll Number</th>
                <th>Attendance</th>
                <th>Remarks</th>
            </tr>

            <?php while ($row = mysqli_fetch_assoc($result)) { ?>

            <tr>
                <td><?php echo $row['student_id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['roll_number']; ?></td>
                <td>
                    <select name="attend_<?php echo $row['student_id']; ?>">
                        <option value="Present">Present</option>
                        <option value="Absent">Absent</option>
                    </select>
                </td>
                <td>
                    <input type="text" name="remark_<?php echo $row['student_id']; ?>">
                </td>
            </tr>

            <?php } ?>

        </table>

        <button type="submit" class="btn btn-primary" name="sub">Submit</button>
        <?php } ?>

    </form>

</div>

</body>
</html>

<?php
if(isset($_POST['sub']))
{


// Get attendance data from POST request
$attendanceDate = $_POST['date'];
$classId = $_POST['class_id'];

// Process attendance records for each student
foreach ($_POST as $key => $value) {
    if (strpos($key, 'attend_') === 0) {
        $studentId = str_replace('attend_', '', $key);
        $attendanceStatus = $value;
        $remarks = $_POST['remark_' . $studentId];

        // Insert attendance record into database
        $sql = "INSERT INTO attendancerecords (student_id, class_id, attendance_date, status, remarks)
                VALUES ($studentId, $classId, '$attendanceDate', '$attendanceStatus', '$remarks')";
        mysqli_query($conn, $sql);
    }
}

// Redirect to attendance page with success message
//header('Location: add_attendance.php?status=submitted');
exit();

}
?>

