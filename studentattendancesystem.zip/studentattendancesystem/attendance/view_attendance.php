<?php
include('../conig.php');

// Get list of classes
$classQuery = "SELECT class_id, class_name FROM Class";
$classResult = mysqli_query($conn, $classQuery);

if (isset($_POST['class_id']) && isset($_POST['attendance_date'])) {
    $selectedClassId = $_POST['class_id'];
    $attendanceDate = $_POST['attendance_date'];
    $sql = "SELECT s.student_id, s.name, s.roll_number, ar.attendance_date, ar.status, ar.remarks
            FROM Students s
            JOIN AttendanceRecords ar ON s.student_id = ar.student_id
            JOIN Class c ON s.class_id = c.class_id
            WHERE c.class_id = $selectedClassId AND ar.attendance_date = '$attendanceDate'";
            $result = mysqli_query($conn, $sql);
} else {
    $selectedClassId = "";
    $attendanceDate = "";
    $sql = "";
}


?>

<html>
<head>
    <title>View Attendance</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>

<div class="container">

    <h2>View Attendance</h2>

    <form method="POST" action="">

        <div class="form-group">
            <label>Select Class:</label>
            <select name="class_id" class="form-control" onchange="this.form.submit()">
                <option value="">Select Class</option>
                <?php while ($classRow = mysqli_fetch_assoc($classResult)) { ?>
                <option value="<?php echo $classRow['class_id']; ?>" <?php if ($classRow['class_id'] == $selectedClassId) echo 'selected'; ?>>
                    <?php echo $classRow['class_name']; ?>
                </option>
                <?php } ?>
            </select>
        </div>

        <div class="form-group">
            <label>Select Date:</label>
            <input type="date" name="attendance_date" class="form-control" value="<?php echo $attendanceDate; ?>" onchange="this.form.submit()">
        </div>

        <?php if ($selectedClassId && $attendanceDate) { ?>
        <table class="table table-bordered">
            <tr>
                <th>Student ID</th>
                <th>Name</th>
                <th>Roll Number</th>
                <th>Attendance Date</th>
                <th>Attendance</th>
                <th>Remarks</th>
            </tr>

            <?php while ($row = mysqli_fetch_assoc($result)) { ?>

            <tr>
                <td><?php echo $row['student_id']; ?></td>
                <td><?php echo $row['name']; ?></td>
                <td><?php echo $row['roll_number']; ?></td>
                <td><?php echo $row['attendance_date']; ?></td>
                <td>
                    <select name="attend_<?php echo $row['student_id']; ?>">
                        <option value="Present" <?php if ($row['status'] == 'Present') echo 'selected'; ?>>Present</option>
                        <option value="Absent" <?php if ($row['status'] == 'Absent') echo 'selected'; ?>>Absent</option>
                    </select>
                </td>
                <td>
                    <input type="text" name="remark_<?php echo $row['student_id']; ?>" value="<?php echo $row['remarks']; ?>">
                </td>
            </tr>

            <?php } ?>

        </table>

        <button type="submit" class="btn btn-primary" name="update_attendance" >Update Attendance</button>
        <?php } ?>

    </form>

</div>

</body>
</html>


<?php

if(isset($_POST['update_attendance']))
{

    
// Get attendance data from POST request
$attendanceDate = $_POST['attendance_date'];
$classId = $_POST['class_id'];


// Process attendance records for each student
foreach ($_POST as $key => $value) {
    if (strpos($key, 'attend_') === 0) {
        $studentId = str_replace('attend_', '', $key);
        $attendanceStatus = $value;
        $remarks = $_POST['remark_' . $studentId];

        // Update attendance record in the database
        $sql = "UPDATE attendancerecords
                SET status = '$attendanceStatus', remarks = '$remarks'
                WHERE student_id = $studentId AND attendance_date = '$attendanceDate'";
        mysqli_query($conn, $sql);
    }
}

// Redirect to view attendance page with success message
header('Location: view_attendance.php');
exit();
}
?>


