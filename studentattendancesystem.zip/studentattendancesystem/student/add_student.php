<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
 
<?php
// Connect to the database
include('../conig.php');
// Get student details from POST request
$name = $_POST["name"];
$rollNumber = $_POST["roll_number"];
$classId = $_POST["class_id"];
$section = $_POST["section"];
$admissionNumber = $_POST["admission_number"];

// Prepare INSERT query
$sql = "INSERT INTO Students (name, roll_number, class_id, section, admission_number) VALUES ('$name', '$rollNumber', $classId, '$section', '$admissionNumber')";

// Execute INSERT query
if (mysqli_query($conn, $sql)) {
  echo "<div class='alert alert-success'>Student added successfully.</div>";
} else {
  echo "<div class='alert alert-danger'>Error adding student: " . mysqli_error($conn) . "</div>";
}

mysqli_close($conn);
?>

<a href="student_add.php" class="btn btn-secondary mt-4">Back to Students</a>
