<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>View Students | Student Attendance System</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <style>
    body {
      padding: 20px;
    }
  </style>
</head>
<body>
<?php
         include('../menu.php');
         ?>
  <div class="container">
    <h1 class="mt-4 mb-4">View Students</h1>

    <table class="table table-bordered table-striped">
      <thead>
        <tr>
          <th>Student ID</th>
          <th>Name</th>
          <th>Roll Number</th>
          <th>Class</th>
          <th>Section</th>
          <th>Admission Number</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php
          // Connect to the database
          include('../conig.php');

          // Fetch student records from database
          $sql = "SELECT s.student_id, s.name, s.roll_number, c.class_name, s.section, s.admission_number FROM Students s JOIN Class c ON s.class_id = c.class_id";
          $result = mysqli_query($conn, $sql);

          if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
              $studentId = $row["student_id"];
              $name = $row["name"];
              $rollNumber = $row["roll_number"];
              $className = $row["class_name"];
              $section = $row["section"];
              $admissionNumber = $row["admission_number"];

              echo "<tr>";
              echo "<td>$studentId</td>";
              echo "<td>$name</td>";
              echo "<td>$rollNumber</td>";
              echo "<td>$className</td>";
              echo "<td>$section</td>";
              echo "<td>$admissionNumber</td>";
              echo "<td>";
              echo "<a href='edit_student.php?id=$studentId' class='btn btn-primary'>Edit</a>";
              echo "&nbsp;";
              echo "<a href='delete_student.php?id=$studentId' class='btn btn-danger'>Delete</a>";
              echo "</td>";
              echo "</tr>";
            }
          } else {
            echo "<tr><td colspan='7' class='text-center'>No students found.</td></tr>";
          }

          mysqli_close($conn);
        ?>
      </tbody>
    </table>

    <a href="student_add.php" class="btn btn-secondary mt-4">Back to Students</a>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>

