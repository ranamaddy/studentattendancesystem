<?php
include('../conig.php');

// Get student ID from URL parameter
$studentId = $_GET["id"];

// Prepare DELETE query
$sql = "DELETE FROM Students WHERE student_id = $studentId";

// Execute DELETE query
if (mysqli_query($conn, $sql)) {
  echo "<div class='alert alert-success'>Student deleted successfully.</div>";
} else {
  echo "<div class='alert alert-danger'>Error deleting student: " . mysqli_error($conn) . "</div>";
}

mysqli_close($conn);
?>

<a href="view_students.php" class="btn btn-secondary mt-4">Back to Students</a>
