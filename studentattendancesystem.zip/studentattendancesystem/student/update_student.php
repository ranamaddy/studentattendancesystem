<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  
<?php
include('../conig.php');

// Get student details from POST request
$studentId = $_POST["student_id"];
$name = $_POST["name"];
$rollNumber = $_POST["roll_number"];
$classId = $_POST["class_id"];
$section = $_POST["section"];
$admissionNumber = $_POST["admission_number"];

// Prepare UPDATE query
$sql = "UPDATE Students SET name = '$name', roll_number = '$rollNumber', class_id = $classId, section = '$section', admission_number = '$admissionNumber' WHERE student_id = $studentId";

// Execute UPDATE query
if (mysqli_query($conn, $sql)) {
  echo "<div class='alert alert-success'>Student updated successfully.</div>";
} else {
  echo "<div class='alert alert-danger'>Error updating student: " . mysqli_error($conn) . "</div>";
}

mysqli_close($conn);
?>

<a href="view_students.php" class="btn btn-secondary mt-4">Back to Students</a>
